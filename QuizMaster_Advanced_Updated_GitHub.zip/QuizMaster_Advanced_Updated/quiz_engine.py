from question_bank import get_quiz_questions
from scoring import calculate_score


def _ask_question(question, number, total):
    print(f"\nQuestion {number}/{total}")
    print(question["question"])
    for key, value in question["options"].items():
        print(f"{key}. {value}")

    while True:
        answer = input("Your answer (A/B/C/D): ").upper().strip()
        if answer in {"A", "B", "C", "D"}:
            return answer
        print("Please enter A, B, C or D.")


def start_quiz(username, category=None, difficulty=None, amount=5, source="local"):
    questions = get_quiz_questions(category, difficulty, amount)

    if not questions:
        print("No matching questions found.")
        return None

    answers = []
    for number, question in enumerate(questions, 1):
        selected = _ask_question(question, number, len(questions))
        answers.append({
            "question": question["question"],
            "selected": selected,
            "correct": question["answer"],
            "options": question["options"],
            "category": question.get("category", "General"),
            "difficulty": question.get("difficulty", "Medium")
        })

    score, percentage = calculate_score(answers)
    result = {
        "username": username,
        "score": score,
        "total": len(questions),
        "percentage": percentage,
        "answers": answers,
        "source": source
    }

    print("\n=== QUIZ COMPLETED ===")
    print(f"Score: {score}/{len(questions)}")
    print(f"Percentage: {percentage:.2f}%")
    return result
