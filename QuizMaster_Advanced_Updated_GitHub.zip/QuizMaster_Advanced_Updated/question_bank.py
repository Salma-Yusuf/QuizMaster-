import json
import os
import random

QUESTIONS_FILE = "data/questions.json"


def load_questions():
    if not os.path.exists(QUESTIONS_FILE):
        return []
    try:
        with open(QUESTIONS_FILE, "r", encoding="utf-8") as file:
            return json.load(file)
    except (json.JSONDecodeError, OSError):
        return []


def save_questions(questions):
    os.makedirs("data", exist_ok=True)
    with open(QUESTIONS_FILE, "w", encoding="utf-8") as file:
        json.dump(questions, file, indent=4, ensure_ascii=False)


def add_question():
    questions = load_questions()
    print("\n=== ADD QUESTION ===")
    question_text = input("Question: ").strip()
    if not question_text:
        print("Question cannot be empty.")
        return

    options = {
        "A": input("Option A: ").strip(),
        "B": input("Option B: ").strip(),
        "C": input("Option C: ").strip(),
        "D": input("Option D: ").strip()
    }
    if any(not value for value in options.values()):
        print("All options are required.")
        return

    answer = input("Correct answer (A/B/C/D): ").upper().strip()
    if answer not in options:
        print("Invalid answer.")
        return

    category = input("Category: ").strip() or "General"
    difficulty = input("Difficulty (Easy/Medium/Hard): ").capitalize().strip()
    if difficulty not in {"Easy", "Medium", "Hard"}:
        print("Invalid difficulty.")
        return

    next_id = max([q.get("id", 0) for q in questions] or [0]) + 1
    questions.append({
        "id": next_id,
        "question": question_text,
        "options": options,
        "answer": answer,
        "category": category,
        "difficulty": difficulty
    })
    save_questions(questions)
    print("Question added successfully.")


def view_questions():
    questions = load_questions()
    print("\n=== QUESTION BANK ===")
    if not questions:
        print("No questions available.")
        return

    for number, q in enumerate(questions, 1):
        print(f"\n{number}. {q['question']}")
        print(f"Category: {q.get('category', 'General')}")
        print(f"Difficulty: {q.get('difficulty', 'Medium')}")
        for key, value in q["options"].items():
            print(f"{key}. {value}")
        print(f"Answer: {q['answer']}")


def delete_question():
    questions = load_questions()
    if not questions:
        print("No questions available.")
        return
    view_questions()
    try:
        number = int(input("\nQuestion number to delete: "))
        if not 1 <= number <= len(questions):
            print("Invalid question number.")
            return
        removed = questions.pop(number - 1)
        for i, q in enumerate(questions, 1):
            q["id"] = i
        save_questions(questions)
        print(f"Deleted: {removed['question']}")
    except ValueError:
        print("Enter a valid number.")


def edit_question():
    questions = load_questions()
    if not questions:
        print("No questions available.")
        return
    view_questions()
    try:
        number = int(input("\nQuestion number to edit: "))
        if not 1 <= number <= len(questions):
            print("Invalid question number.")
            return
        q = questions[number - 1]
        text = input(f"Question [{q['question']}]: ").strip()
        if text:
            q["question"] = text

        for key in "ABCD":
            value = input(f"Option {key} [{q['options'][key]}]: ").strip()
            if value:
                q["options"][key] = value

        answer = input(f"Correct answer [{q['answer']}]: ").upper().strip()
        if answer in q["options"]:
            q["answer"] = answer

        category = input(f"Category [{q.get('category', 'General')}]: ").strip()
        if category:
            q["category"] = category

        difficulty = input(f"Difficulty [{q.get('difficulty', 'Medium')}]: ").capitalize().strip()
        if difficulty in {"Easy", "Medium", "Hard"}:
            q["difficulty"] = difficulty

        save_questions(questions)
        print("Question updated.")
    except ValueError:
        print("Enter a valid number.")


def get_categories():
    return sorted({q.get("category", "General") for q in load_questions()})


def get_quiz_questions(category=None, difficulty=None, amount=5):
    questions = load_questions()
    if category:
        questions = [q for q in questions if q.get("category", "").lower() == category.lower()]
    if difficulty:
        questions = [q for q in questions if q.get("difficulty", "").lower() == difficulty.lower()]
    random.shuffle(questions)
    return questions[:max(1, amount)]


def import_questions(new_questions):
    questions = load_questions()
    next_id = max([q.get("id", 0) for q in questions] or [0]) + 1
    for q in new_questions:
        q = dict(q)
        q["id"] = next_id
        next_id += 1
        questions.append(q)
    save_questions(questions)
    return len(new_questions)
