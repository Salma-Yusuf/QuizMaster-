from question_bank import add_question, view_questions, edit_question, delete_question
from leaderboard import show_leaderboard


def admin_dashboard():
    while True:
        print("\n=== ADMIN DASHBOARD ===")
        print("1. Add Question")
        print("2. View Questions")
        print("3. Edit Question")
        print("4. Delete Question")
        print("5. View Leaderboard")
        print("6. Exit")

        choice = input("Choose an option: ").strip()

        if choice == "1":
            add_question()
        elif choice == "2":
            view_questions()
        elif choice == "3":
            edit_question()
        elif choice == "4":
            delete_question()
        elif choice == "5":
            show_leaderboard()
        elif choice == "6":
            break
        else:
            print("Invalid choice.")
