import json
import os
import hashlib

USERS_FILE = "data/users.json"


def _hash_password(password):
    return hashlib.sha256(password.encode("utf-8")).hexdigest()


def load_users():
    if not os.path.exists(USERS_FILE):
        return []
    try:
        with open(USERS_FILE, "r", encoding="utf-8") as file:
            return json.load(file)
    except (json.JSONDecodeError, OSError):
        return []


def save_users(users):
    os.makedirs("data", exist_ok=True)
    with open(USERS_FILE, "w", encoding="utf-8") as file:
        json.dump(users, file, indent=4)


def register_user():
    users = load_users()
    print("\n=== STUDENT REGISTRATION ===")
    username = input("Username: ").strip()
    password = input("Password: ").strip()

    if not username or not password:
        print("Username and password cannot be empty.")
        return None

    if any(u["username"].lower() == username.lower() for u in users):
        print("Username already exists.")
        return None

    users.append({
        "username": username,
        "password": _hash_password(password),
        "role": "student"
    })
    save_users(users)
    print("Registration successful.")
    return username


def login_user():
    users = load_users()
    print("\n=== STUDENT LOGIN ===")
    username = input("Username: ").strip()
    password = input("Password: ").strip()
    password_hash = _hash_password(password)

    for user in users:
        if (user["username"] == username
                and user["password"] == password_hash
                and user["role"] == "student"):
            print("Login successful.")
            return user

    print("Invalid username or password.")
    return None


def admin_login():
    print("\n=== ADMIN LOGIN ===")
    username = input("Username: ").strip()
    password = input("Password: ").strip()

    admin_user = os.getenv("QUIZMASTER_ADMIN_USER", "admin")
    admin_password = os.getenv("QUIZMASTER_ADMIN_PASSWORD", "admin123")

    if username == admin_user and password == admin_password:
        print("Admin login successful.")
        return {"username": username, "role": "admin"}

    print("Invalid admin credentials.")
    return None
