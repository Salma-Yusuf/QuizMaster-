import os

APP_NAME = "QuizMaster V2"
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
API_TIMEOUT = 12
